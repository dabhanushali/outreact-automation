// Start the admin panel server
import("./api/server.js");
